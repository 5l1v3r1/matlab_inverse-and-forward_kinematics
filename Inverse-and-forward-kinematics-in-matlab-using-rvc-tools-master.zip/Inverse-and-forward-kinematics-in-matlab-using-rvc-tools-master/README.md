# Inverse-and-forward-kinematics-in-matlab-using-rvc-tools
simple matlab operation for forward and inverse kinematics
